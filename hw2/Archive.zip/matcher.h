/**
 * Functions to implement in matcher.c
 * You must not change this file.
 */

#ifndef _RGREP_MATCHER_H
#define _RGREP_MATCHER_H

/* declaration of your matcher function */
int rgrep_matches(char *line, char *pattern);

#endif
